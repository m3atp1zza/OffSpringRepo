# -*- coding: utf-8 -*-
#  ___  ____  _  _
# / __)( ___)( \/ )
#( (_-. )__)  \  /
# \___/(__)   (__)
#
#All credits to previous ...